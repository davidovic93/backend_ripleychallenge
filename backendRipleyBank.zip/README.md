#Instrucciones

1. Abrir una terminal (cmd o vscode por ejemplo).
2. Copiar siguiente sentencia: "git clone https://github.com/davidovic93/rockpaperscissors_back_dmaldonado.git".
3. Posicionarse en el directorio con: "cd rockpaperscissors_back_dmaldonado".
4. Instalar modulos: "npm i".
5. Ejecutar proyecto: "npm run dev".

#Otra consideración

- Base de datos se encuentra en linea, se puede visualizar en "variables.env".